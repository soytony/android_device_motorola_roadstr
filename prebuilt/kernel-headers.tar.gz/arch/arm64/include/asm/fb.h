/* SPDX-License-Identifier: GPL-2.0-only */

#ifndef __ASM_FB_H_
#define __ASM_FB_H_

#include <asm-generic/fb.h>

#endif 
